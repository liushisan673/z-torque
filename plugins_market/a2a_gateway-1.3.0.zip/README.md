# a2a_gateway 1.3.0 — Agent-to-Agent 网关

## 作用
A2A 协议入站 / 出站：身份传播（`none` / `user_id_header` / `full_context_token`）、
调用深度与扇出限制、出站网络白名单。

## 装完还需要什么
- `A2A_ENABLED=true`（默认 false；关闭时端点仍注册，返回 503 `AI_A2A_DISABLED`）
- 权限 `a2a.invoke`（安装器已种入；普通成员角色默认不授予）
- 入站鉴权：未带凭据 → 403 `AI_A2A_DENIED`（这是闸门，不是故障）

## 验证
`POST /api/z-torque/a2a/invoke`
未授权 → 403 `AI_A2A_DENIED`；开关关闭 → 503 `AI_A2A_DISABLED`；
未装配 → 503 `AI_CAPABILITY_UNAVAILABLE`
