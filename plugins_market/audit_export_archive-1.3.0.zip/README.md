# audit_export_archive 1.3.0 — 审计导出与归档

## 作用
按筛选范围把审计日志**脱敏导出**为 JSONL / CSV 分片（后台任务 + 前台轮询 + 分片下载），
并支持归档批次（可选加密、密钥轮换）。

## 装完还需要什么
- 权限：`audit.export`（导出）、`audit.archive`（归档）—— 安装器会跑一次权限种子，
  admin 角色自动获得（不装权限则前端入口不渲染，这是刻意的）
- 格式白名单：`AUDIT_EXPORT_FORMATS` 默认 `["jsonl"]`；本包安装时放开 `["jsonl","csv"]`

## 验证
前端：审计页 →「导出与归档」→ 导出当前筛选 → 轮询到 SUCCEEDED → 查看分片 → 下载
接口：`POST /api/z-torque/audit-exports`
