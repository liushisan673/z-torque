# sandbox_driver 1.3.0 — MD-Script 执行沙箱

## 作用
把 MD-Skill 里的脚本执行关进沙箱：独立进程 + POSIX rlimit（CPU / 文件大小 / 进程数）
+ 工作目录白名单。未装配时 MD-Script 返回 503 AI_CAPABILITY_UNAVAILABLE。

## 本包的特殊之处
社区版已经内置装配（`execution` 模块），所以「安装」只做**启用**：
`MD_SKILL_SCRIPT_ENABLED` 默认 false（脚本一律不执行），安装后置为 true。

## 启用后仍然受这些约束
- `SANDBOX_ALLOWED_ROOTS` 白名单（未配置 → `[MD_SKILLS_DIR]`；显式空数组 = 装配失败）
- `SANDBOX_MAX_PROCESSES` / `SANDBOX_MAX_FILE_BYTES`
- Windows 没有 rlimit 语义，capabilities 会如实上报 `rlimit=False`、`isolation_level=none`

## 验证
`GET /api/z-torque/capabilities` → `data.sandbox.available == true`
